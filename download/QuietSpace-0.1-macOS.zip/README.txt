静界 QuietSpace 0.1
macOS 14+ · Universal (Apple Silicon / Intel)

演示账号：demo
密码：123456

打开方式：
1. 解压后双击「QuietSpace.app」
2. 如果 macOS 提示“无法验证开发者”：
   - 右键 App → 打开 → 再点“打开”
   - 或在终端执行：
     xattr -dr com.apple.quarantine "/Applications/QuietSpace.app"

说明：
- 数据只保存在本机，不需要联网
- Apple Watch 为模拟授权，未真正接入 HealthKit
- 源码：https://github.com/ZFZ15/quietspace

由 Fantôme 制作
